setwd("E:\\Kafeel\\Intro to R")
library(readxl)
#Load the workbook
wb=read_excel("customers.xlsx")

#Get sheet names in the excel
excel_sheets("customers.xlsx")

#Import the worksheet by name or number
california=read_excel("customers.xlsx", sheet = "california")
head(california)
head(wb)

excel_sheets("customers.xlsx")
data=read_excel("customers.xlsx",sheet=3)
head(data)

#Import first 5 rows from new sheet
new=read_excel("customers.xlsx",sheet="new sheet",n_max=5) #By default it will look for sheet 1.
new

#Import the file using cell range.
read_excel("customers.xlsx", range = "C1:E4")

#readxl includes several example files
readxl_example()

#Import .xls files into R
xls=readxl_example("deaths.xls")
death=read_excel(xls)

#Sheet names
excel_sheets(xls)
head(death)

#Replace the 60 as NA
death=read_excel(xls,na=c(60,"Age"))
head(death)

#Importing html files into R
library(XML)
x = readHTMLTable('http://apps.saferoutesinfo.org/legislation_funding/state_apportionment.cfm')
str(x)

state=as.data.frame(x[1])
dim(state)
head(state)

#Renaming the column
names(state)
names(state)<-c("State",paste0('Actual',2005:2012),"Total")
head(state)

#Write data frames into csv file
write.csv(state,"state.csv",row.names=FALSE)

#Install "knitr" package using install.packages("knitr")