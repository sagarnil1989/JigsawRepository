personId<-c(1,2,3,4,5)
personWt<-c(60,70,80,65,75)

person<-data.frame(personId,personWt)
person

plot(person)

